//
//  ViewController.m
//  iOS firstProject
//
//  Created by izaodao on 16/4/21.
//  Copyright © 2016年 izaodao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic,strong)UILabel *statusLable;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   //不透明橡树的点击效果方法；
    
    UIImageView *bgimageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    bgimageView.image = [UIImage imageNamed:@"背景"];
    bgimageView.userInteractionEnabled = YES;
    [self.view addSubview:bgimageView];
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    UIImageView *secondImageView = [[UIImageView alloc]init];
    secondImageView.backgroundColor = [UIColor grayColor];
    secondImageView.userInteractionEnabled = YES;
    UIImage *firstImage = [UIImage imageNamed:@"地图1"];
    secondImageView.image = firstImage;
    CGFloat secondX = (size.width - firstImage.size.width)/2;
    CGFloat secondH = (size.height - firstImage.size.height)/2;
    secondImageView.frame = CGRectMake(secondX, secondH, firstImage.size.width, firstImage.size.height);
    [self.view addSubview:secondImageView];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickToResbonde:)];
    tap.numberOfTouchesRequired = 1;
    [secondImageView addGestureRecognizer:tap];
    
    
    _statusLable = [[UILabel alloc]init];
    _statusLable.backgroundColor = [UIColor redColor];
    _statusLable.textAlignment = NSTextAlignmentCenter;
    _statusLable.textColor = [UIColor blackColor];
    _statusLable.frame = CGRectMake(CGRectGetMinX(secondImageView.frame), CGRectGetMaxY(secondImageView.frame)+5,firstImage.size.width, 50);
    [self.view addSubview:_statusLable];
    
}


-(void)clickToResbonde:(UITapGestureRecognizer *)tap{

    CGPoint point = [tap locationInView:tap.view];
   int clickValue = [self GetImagePixel:(UIImageView *)tap.view pointX:point.x/tap.view.frame.size.width pointY:point.y/tap.view.frame.size.height];
    if (clickValue == 255) {
        _statusLable.text = @"此区域可以点击";
    }else{
      _statusLable.text = @"此区域不可以点击";
    }

}

- (int)GetImagePixel:(UIImageView *)imageView pointX:(float) x pointY:(float)y {
    /**
     imageView 被点击的图片是否可以点击
     pointX 点击的点得横坐标与点击图片宽的比例
     pointY 点击的点得纵坐标与点击图片高的比例
     */
    if(!(x >= 0.0 && x < 1.0 && y >= 0.0 && y<1.0)) {
        return 0;
    }
    CGImageRef rawImageRef = [imageView.image CGImage];
    const UInt8 *rawPixelData = CFDataGetBytePtr(CGDataProviderCopyData(CGImageGetDataProvider(rawImageRef)));
    NSUInteger imageHeight = CGImageGetHeight(rawImageRef);
    NSUInteger imageWidth = CGImageGetWidth(rawImageRef);
    int w = imageWidth * x;
    int h = imageHeight * y;
    int i = (int)(h * CGImageGetBytesPerRow(rawImageRef) + w*CGImageGetBitsPerPixel(rawImageRef)/CGImageGetBitsPerComponent(rawImageRef));
    int a = (unsigned int)rawPixelData[i+3];
    return a;
}
@end
